import 'preact/debug';
import './components/app';
