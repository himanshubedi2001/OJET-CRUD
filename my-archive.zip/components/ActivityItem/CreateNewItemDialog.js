define(["require", "exports", "preact/jsx-runtime", "preact/hooks", "ojs/ojdialog"], function (require, exports, jsx_runtime_1, hooks_1) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    const CreateNewItemDialog = (props) => {
        const createDialogRef = (0, hooks_1.useRef)(null);
        const closeDialog = () => {
            props.closeDialog(createDialogRef, "create");
        };
        (0, hooks_1.useEffect)(() => {
            var _a, _b;
            props.isOpened
                ? (_a = createDialogRef.current) === null || _a === void 0 ? void 0 : _a.open()
                : (_b = createDialogRef.current) === null || _b === void 0 ? void 0 : _b.close();
        }, [props.isOpened]);
        const [formData, setFormData] = (0, hooks_1.useState)({});
        const onChangeHandler = (event) => {
            setFormData(Object.assign(Object.assign({}, formData), { [event.currentTarget.id]: event.detail.value }));
        };
        const createItem = () => {
            console.log("data: " + JSON.stringify(formData));
            props.createNewItem(formData, createDialogRef);
        };
        return ((0, jsx_runtime_1.jsx)("span", { children: (0, jsx_runtime_1.jsxs)("oj-dialog", { id: "createDialog", ref: createDialogRef, dialogTitle: "Create New Item", onojClose: closeDialog, cancelBehavior: "icon", children: [(0, jsx_runtime_1.jsx)("div", { slot: "body", children: (0, jsx_runtime_1.jsxs)("oj-form-layout", { children: [(0, jsx_runtime_1.jsx)("oj-input-text", { id: "name", labelHint: "Name", onvalueChanged: onChangeHandler }), (0, jsx_runtime_1.jsx)("oj-input-text", { id: "price", labelHint: "Price", onvalueChanged: onChangeHandler }), (0, jsx_runtime_1.jsx)("oj-input-text", { id: "short_desc", labelHint: "Description", onvalueChanged: onChangeHandler }), (0, jsx_runtime_1.jsx)("oj-input-text", { id: "quantity_instock", labelHint: "Quantity: In-Stock", onvalueChanged: onChangeHandler }), (0, jsx_runtime_1.jsx)("oj-input-text", { id: "quantity_shipped", labelHint: "Quantity: Shipped", onvalueChanged: onChangeHandler })] }) }), (0, jsx_runtime_1.jsx)("div", { slot: "footer", children: (0, jsx_runtime_1.jsx)("oj-button", { id: "submitBtn", onojAction: createItem, children: "Submit" }) })] }) }));
    };
    exports.default = CreateNewItemDialog;
});
//# sourceMappingURL=CreateNewItemDialog.js.map