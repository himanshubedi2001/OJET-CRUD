import { h } from "preact";
import { MutableRef } from "preact/hooks";
import "ojs/ojdialog";
import { ojDialog } from "ojs/ojdialog";
type Props = {
    isOpened: boolean;
    closeDialog: (ref: MutableRef<ojDialog>, type: string) => void;
    editItem: (data: Partial<Item>, ref: MutableRef<ojDialog>) => void;
    itemData: Partial<Item>;
};
type Item = {
    id: number;
    name: string | undefined;
    short_desc?: string;
    price?: number;
    quantity?: number;
    quantity_shipped?: number;
    quantity_instock?: number;
    activity_id?: number;
    image?: string;
};
declare const EditItemDialog: (props: Props) => h.JSX.Element;
export default EditItemDialog;
