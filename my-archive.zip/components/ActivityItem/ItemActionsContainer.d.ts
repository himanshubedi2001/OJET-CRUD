import { h } from "preact";
import "ojs/ojbutton";
type Props = {
    create: () => void;
    edit: () => void;
    itemSelected: Partial<Item>;
};
type Item = {
    id: number;
    name: string;
    short_desc?: string;
    price?: number;
    quantity?: number;
    quantity_shipped?: number;
    quantity_instock?: number;
    activity_id?: number;
    image?: string;
};
declare const ItemActionsContainer: (props: Props) => h.JSX.Element;
export default ItemActionsContainer;
