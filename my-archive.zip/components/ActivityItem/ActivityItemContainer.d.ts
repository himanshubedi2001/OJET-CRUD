import { h } from "preact";
import "ojs/ojlistview";
import { RESTDataProvider } from "ojs/ojrestdataprovider";
import "ojs/ojformlayout";
import "ojs/ojinputtext";
type Props = {
    data?: RESTDataProvider<any, any>;
    selectedActivity: Item | null;
    onItemChanged: (item: Item) => void;
};
type Item = {
    id: number;
    name: string;
    short_desc?: string;
    price?: number;
    quantity?: number;
    quantity_shipped?: number;
    quantity_instock?: number;
    activity_id?: number;
    image?: string;
};
declare const ActivityItemContainer: (props: Props) => h.JSX.Element;
export default ActivityItemContainer;
