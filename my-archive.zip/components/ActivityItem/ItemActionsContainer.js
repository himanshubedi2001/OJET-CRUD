define(["require", "exports", "preact/jsx-runtime", "preact/hooks", "ojs/ojbutton"], function (require, exports, jsx_runtime_1, hooks_1) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    const ItemActionsContainer = (props) => {
        var _a;
        const [hideActions, setHideActions] = (0, hooks_1.useState)(true);
        if ((_a = props.itemSelected) === null || _a === void 0 ? void 0 : _a.id) {
            console.log("Selected: " + JSON.stringify(props.itemSelected));
        }
        (0, hooks_1.useEffect)(() => {
            var _a;
            if ((_a = props.itemSelected) === null || _a === void 0 ? void 0 : _a.id) {
                setHideActions(false);
            }
            else {
                setHideActions(true);
            }
        }, [props.itemSelected]);
        return ((0, jsx_runtime_1.jsxs)("div", { children: [(0, jsx_runtime_1.jsx)("oj-button", { id: "createButton", onojAction: props.create, children: "Create" }), (0, jsx_runtime_1.jsx)("oj-button", { id: "updateButton", disabled: hideActions, onojAction: props.edit, children: "Update" })] }));
    };
    exports.default = ItemActionsContainer;
});
//# sourceMappingURL=ItemActionsContainer.js.map