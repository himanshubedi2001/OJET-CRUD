var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
define(["require", "exports", "preact/jsx-runtime", "preact/hooks", "./ItemActionsContainer", "./CreateNewItemDialog", "./EditItemDialog", "ojs/ojlistview", "ojs/ojformlayout", "ojs/ojinputtext"], function (require, exports, jsx_runtime_1, hooks_1, ItemActionsContainer_1, CreateNewItemDialog_1, EditItemDialog_1) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    const DEFAULT_ACTIVITY_ITEM_STATE = {};
    const listItemRenderer = (item) => {
        const image = item.data.image.replace("css", "styles");
        return ((0, jsx_runtime_1.jsxs)("div", { class: "oj-flex no-wrap", children: [(0, jsx_runtime_1.jsx)("span", { class: "demo-thumbnail oj-flex-item", style: "background-image:url(" + image + ")" }), (0, jsx_runtime_1.jsxs)("div", { class: "demo-content oj-flex-item", children: [(0, jsx_runtime_1.jsx)("div", { children: (0, jsx_runtime_1.jsx)("strong", { children: item.data.name }) }), (0, jsx_runtime_1.jsx)("span", { class: "demo-metadata", children: item.data.short_desc })] })] }));
    };
    const gridlinesItemVisible = { item: "visible" };
    const scrollPolicyOpts = { fetchSize: 5 };
    const ActivityItemContainer = (props) => {
        var _a;
        const activityItemDataProvider = props.data;
        const restServerURLItems = "https://apex.oracle.com/pls/apex/oraclejet/lp/activities/" + ((_a = props.selectedActivity) === null || _a === void 0 ? void 0 : _a.id) + "/items/";
        const [isCreateOpened, setIsCreateOpened] = (0, hooks_1.useState)(false);
        const [isEditOpened, setIsEditOpened] = (0, hooks_1.useState)(false);
        const [itemData, setItemData] = (0, hooks_1.useState)(props.selectedActivity);
        const openCreateDialog = () => {
            console.log("CreateNewItemDialog called");
            setIsCreateOpened(true);
        };
        const [activityItemValue, setActivityItemValue] = (0, hooks_1.useState)(DEFAULT_ACTIVITY_ITEM_STATE);
        const selectedActivityItemChanged = (0, hooks_1.useCallback)((event) => {
            let tempItem = event.detail.value.data;
            props.onItemChanged(tempItem);
            setActivityItemValue(tempItem);
            setItemData(tempItem);
        }, [activityItemValue]);
        const handleDialogClose = (ref, type) => {
            type === "create" ? setIsCreateOpened(false) : setIsEditOpened(false);
            ref.current.close();
        };
        const createItem = (data, createDialogRef) => __awaiter(void 0, void 0, void 0, function* () {
            var _b;
            if (data === null || data === void 0 ? void 0 : data.name) {
                let quantity = Number(data.quantity_instock) + Number(data.quantity_shipped);
                const row = {
                    name: data.name,
                    short_desc: data.short_desc,
                    price: data.price,
                    quantity_instock: data.quantity_instock,
                    quantity_shipped: data.quantity_shipped,
                    quantity: quantity,
                    activity_id: (_b = props.selectedActivity) === null || _b === void 0 ? void 0 : _b.id,
                    image: "css/images/product_images/jet_logo_256.png",
                };
                const request = new Request(restServerURLItems, {
                    headers: new Headers({
                        "Content-type": "application/json; charset=UTF-8",
                    }),
                    body: JSON.stringify(row),
                    method: "POST",
                });
                const response = yield fetch(request);
                const addedRow = yield response.json();
                activityItemDataProvider === null || activityItemDataProvider === void 0 ? void 0 : activityItemDataProvider.refresh();
                console.log("Created new item");
                createDialogRef.current.close();
            }
        });
        const openEditDialog = () => {
            console.log("Item: " + JSON.stringify(itemData));
            setIsEditOpened(true);
            console.log("Edit dialog opened");
        };
        const editItem = (newItemData, editDialogRef = (0, hooks_1.useRef)()) => __awaiter(void 0, void 0, void 0, function* () {
            var _c, _d;
            if (newItemData != null) {
                const row = {
                    itemId: newItemData.id,
                    name: newItemData.name,
                    price: newItemData.price,
                    short_desc: newItemData.short_desc,
                };
                const request = new Request(`${restServerURLItems}${itemData.id}`, {
                    headers: new Headers({
                        "Content-type": "application/json; charset=UTF-8",
                    }),
                    body: JSON.stringify(row),
                    method: "PUT",
                });
                const response = yield fetch(request);
                const updatedRow = yield response.json();
                const updatedRowKey = itemData.id;
                const updatedRowMetaData = { key: updatedRowKey };
                (_c = props.data) === null || _c === void 0 ? void 0 : _c.mutate({
                    update: {
                        data: [updatedRow],
                        keys: new Set([updatedRowKey]),
                        metadata: [updatedRowMetaData],
                    },
                });
            }
            console.log("Edited item");
            (_d = editDialogRef.current) === null || _d === void 0 ? void 0 : _d.close();
        });
        return ((0, jsx_runtime_1.jsx)("div", { id: "activityItemsContainer", class: "oj-flex-item oj-sm-padding-4x-start oj-md-6 oj-sm-12", children: (0, jsx_runtime_1.jsxs)("div", { id: "container", children: [(0, jsx_runtime_1.jsx)("h3", { children: "Activity Items" }), (0, jsx_runtime_1.jsx)(ItemActionsContainer_1.default, { create: openCreateDialog, itemSelected: activityItemValue, edit: openEditDialog }), (0, jsx_runtime_1.jsx)(CreateNewItemDialog_1.default, { isOpened: isCreateOpened, createNewItem: createItem, closeDialog: handleDialogClose }), (0, jsx_runtime_1.jsx)(EditItemDialog_1.default, { isOpened: isEditOpened, editItem: editItem, closeDialog: handleDialogClose, itemData: itemData }), (0, jsx_runtime_1.jsx)("oj-list-view", { id: "itemsList", class: "item-display", "aria-labelledby": "activitiesHeader", data: activityItemDataProvider, gridlines: gridlinesItemVisible, selectionMode: "single", onfirstSelectedItemChanged: selectedActivityItemChanged, scrollPolicy: "loadMoreOnScroll", scrollPolicyOptions: scrollPolicyOpts, children: (0, jsx_runtime_1.jsx)("template", { slot: "itemTemplate", render: listItemRenderer }) })] }) }));
    };
    exports.default = ActivityItemContainer;
});
//# sourceMappingURL=ActivityItemContainer.js.map