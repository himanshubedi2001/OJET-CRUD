define(["require", "exports", "preact/jsx-runtime", "preact/hooks", "ojs/ojdialog"], function (require, exports, jsx_runtime_1, hooks_1) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    const EditItemDialog = (props) => {
        const editDialogRef = (0, hooks_1.useRef)();
        const [editFormData, setEditFormData] = (0, hooks_1.useState)({});
        const onChangeHandler = (event) => {
            if (event.detail.updatedFrom === "internal") {
                setEditFormData(Object.assign(Object.assign({}, editFormData), { [event.currentTarget.id]: event.detail.value }));
            }
        };
        const closeDialog = () => {
            props.closeDialog(editDialogRef, "edit");
        };
        const editItem = () => {
            console.log("data: " + JSON.stringify(editFormData));
            props.editItem(editFormData, editDialogRef);
        };
        (0, hooks_1.useEffect)(() => {
            var _a, _b;
            setEditFormData(props.itemData);
            props.isOpened ? (_a = editDialogRef.current) === null || _a === void 0 ? void 0 : _a.open() : (_b = editDialogRef.current) === null || _b === void 0 ? void 0 : _b.close();
        }, [props.isOpened]);
        return ((0, jsx_runtime_1.jsx)("span", { children: (0, jsx_runtime_1.jsxs)("oj-dialog", { id: "editDialog", ref: editDialogRef, dialogTitle: "Update Item Details", onojClose: closeDialog, cancelBehavior: "icon", children: [(0, jsx_runtime_1.jsxs)("div", { slot: "body", children: [(0, jsx_runtime_1.jsxs)("oj-label-value", { labelEdge: "inside", children: [(0, jsx_runtime_1.jsx)("oj-label", { for: "itemid", slot: "label", children: "Item ID" }), (0, jsx_runtime_1.jsx)("div", { id: "itemid", slot: "value", class: "slot-line", children: editFormData === null || editFormData === void 0 ? void 0 : editFormData.id })] }), (0, jsx_runtime_1.jsxs)("oj-form-layout", { children: [(0, jsx_runtime_1.jsx)("oj-input-text", { id: "name", labelHint: "Name", onvalueChanged: onChangeHandler, value: editFormData === null || editFormData === void 0 ? void 0 : editFormData.name }), (0, jsx_runtime_1.jsx)("oj-input-text", { id: "price", labelHint: "Price", onvalueChanged: onChangeHandler, value: editFormData === null || editFormData === void 0 ? void 0 : editFormData.price }), (0, jsx_runtime_1.jsx)("oj-input-text", { id: "short_desc", labelHint: "Description", onvalueChanged: onChangeHandler, value: editFormData === null || editFormData === void 0 ? void 0 : editFormData.short_desc })] })] }), (0, jsx_runtime_1.jsx)("div", { slot: "footer", children: (0, jsx_runtime_1.jsx)("oj-button", { id: "submitBtn", onojAction: editItem, children: "Submit" }) })] }) }));
    };
    exports.default = EditItemDialog;
});
//# sourceMappingURL=EditItemDialog.js.map