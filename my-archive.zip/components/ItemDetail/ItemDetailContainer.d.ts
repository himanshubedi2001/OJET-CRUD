import { h } from "preact";
import "ojs/ojlabel";
import "ojs/ojselectsingle";
import "ojs/ojchart";
import "ojs/ojlistview";
import "ojs/ojlistitemlayout";
import "ojs/ojavatar";
type Props = {
    item?: Item | null;
};
type Item = {
    id: number;
    name: string;
    short_desc?: string;
    price?: number;
    quantity?: number;
    quantity_shipped?: number;
    quantity_instock?: number;
    activity_id?: number;
    image?: string;
};
declare const ItemDetailContainer: (props: Props) => h.JSX.Element;
export default ItemDetailContainer;
