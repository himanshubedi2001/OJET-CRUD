define(["require", "exports", "preact/jsx-runtime", "ojs/ojmutablearraydataprovider", "text!../storeData.json", "ojs/ojlabel", "ojs/ojselectsingle", "ojs/ojchart", "ojs/ojlistview", "ojs/ojlistitemlayout", "ojs/ojavatar"], function (require, exports, jsx_runtime_1, MutableArrayDataProvider, storeData) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    const ItemDetailContainer = (props) => {
        var _a, _b, _c, _d, _e, _f, _g, _h, _j;
        const activityDataProvider = new MutableArrayDataProvider(JSON.parse(storeData), {
            keyAttributes: "id"
        });
        const gridlinesItemVisible = { item: "visible" };
        const chartTypesDPData = [
            { value: 'pie', label: 'Pie Chart' },
            { value: 'bar', label: 'Bar Chart' },
            { value: 'line', label: 'Line Chart' },
            { value: 'area', label: 'Area Chart' }
        ];
        const dataProvider = new MutableArrayDataProvider(chartTypesDPData, {
            keyAttributes: "value"
        });
        const chartTypesDP = new MutableArrayDataProvider(chartTypesDPData, { keyAttributes: "value" });
        const chartData = [
            { "id": 0, "series": "Baseball", "group": "Group A", "value": 42 },
            { "id": 1, "series": "Baseball", "group": "Group B", "value": 34 },
            { "id": 2, "series": "Bicycling", "group": "Group A", "value": 55 },
            { "id": 3, "series": "Bicycling", "group": "Group B", "value": 30 },
            { "id": 4, "series": "Skiing", "group": "Group A", "value": 36 },
            { "id": 5, "series": "Skiing", "group": "Group B", "value": 50 },
            { "id": 6, "series": "Soccer", "group": "Group A", "value": 22 },
            { "id": 7, "series": "Soccer", "group": "Group B", "value": 46 }
        ];
        const chartDataProvider = new MutableArrayDataProvider(chartData, { keyAttributes: "value" });
        const chartItem = (item) => {
            return ((0, jsx_runtime_1.jsx)("oj-chart-item", { value: item.data.value, groupId: [0], seriesId: item.data.series }));
        };
        const pieDataProvider = new MutableArrayDataProvider([
            { series: "Quantity in Stock", value: (_a = props.item) === null || _a === void 0 ? void 0 : _a.quantity_instock },
            { series: "Quantity shipped", value: (_b = props.item) === null || _b === void 0 ? void 0 : _b.quantity_shipped },
        ], { keyAttributes: "id" });
        console.log("props\n", props);
        return ((0, jsx_runtime_1.jsxs)("div", { id: "itemDetailsContainer", class: "oj-flex-item oj-bg-neutral-30 oj-sm-padding-4x-start oj-md-6 oj-sm-12", children: [(0, jsx_runtime_1.jsx)("h3", { children: "Item Details" }), (0, jsx_runtime_1.jsx)("hr", { class: "hr-margin" }), (0, jsx_runtime_1.jsx)("oj-avatar", { role: "img", size: "lg", "aria-label": "product image for" + ((_c = props.item) === null || _c === void 0 ? void 0 : _c.name), src: (_e = (_d = props.item) === null || _d === void 0 ? void 0 : _d.image) === null || _e === void 0 ? void 0 : _e.replace("css", "styles"), class: "float-right" }), (0, jsx_runtime_1.jsx)("div", { id: "itemName", class: "data-name", children: (_f = props.item) === null || _f === void 0 ? void 0 : _f.name }), (0, jsx_runtime_1.jsx)("div", { id: "itemDesc", class: "data-desc", children: (_g = props.item) === null || _g === void 0 ? void 0 : _g.short_desc }), (0, jsx_runtime_1.jsx)("div", { id: "itemPrice", children: "Price: " + ((_h = props.item) === null || _h === void 0 ? void 0 : _h.price) + " each" }), (0, jsx_runtime_1.jsx)("div", { id: "itemId", children: "Item Id: " + ((_j = props.item) === null || _j === void 0 ? void 0 : _j.id) }), (0, jsx_runtime_1.jsx)("div", { children: (0, jsx_runtime_1.jsx)("oj-chart", { id: "pieChart", type: "pie", data: pieDataProvider, animationOnDisplay: "auto", animationOnDataChange: "auto", hoverBehavior: "dim", class: "chartStyle", children: (0, jsx_runtime_1.jsx)("template", { slot: "itemTemplate", render: chartItem }) }) })] }));
    };
    exports.default = ItemDetailContainer;
});
//# sourceMappingURL=ItemDetailContainer.js.map