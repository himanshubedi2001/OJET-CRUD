import { h } from "preact";
type Props = {
    activity: Item | null;
};
type Item = {
    id: number;
    name: string;
    short_desc?: string;
    price?: number;
    quantity?: number;
    quantity_shipped?: number;
    quantity_instock?: number;
    activity_id?: number;
    image?: string;
};
declare const ParentContainer2: (props: Props) => h.JSX.Element;
export default ParentContainer2;
