define(["require", "exports", "preact/jsx-runtime", "ojs/ojkeyset", "preact/hooks", "ojs/ojlistview"], function (require, exports, jsx_runtime_1, ojkeyset_1, hooks_1) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    const listItemRenderer = (item) => {
        console.log(item);
        let image = item.data.image.replace("css", "styles");
        console.log("image", image);
        return ((0, jsx_runtime_1.jsxs)("div", { class: "oj-flex no-wrap", children: [(0, jsx_runtime_1.jsx)("span", { class: "demo-thumbnail oj-flex-item", style: "background-image:url(" + image + ")" }), (0, jsx_runtime_1.jsxs)("div", { class: "demo-content oj-flex-item", children: [(0, jsx_runtime_1.jsx)("div", { children: (0, jsx_runtime_1.jsx)("strong", { children: item.data.name }) }), (0, jsx_runtime_1.jsx)("span", { class: "demo-metadata", children: item.data.short_desc })] })] }));
    };
    const gridlinesItemVisible = { item: "visible" };
    const scrollPolicyOpts = { fetchSize: 5 };
    const ActivityContainer = (props) => {
        console.log("Activity container function \n", props);
        const selectedActivityChanged = (event) => {
            props.onActiivityChanged(event.detail.value.data);
        };
        const activityValue = (0, hooks_1.useMemo)(() => {
            return new ojkeyset_1.KeySetImpl([props.value]);
        }, [props.value]);
        console.log(props.value, "Acttivity contaiber debug");
        console.log("Activity value\n", activityValue);
        return ((0, jsx_runtime_1.jsxs)("div", { id: "activitiesContainer", class: "oj-flex-item oj-bg-info-30 oj-sm-padding-4x-start oj-md-4 oj-sm-12", children: [(0, jsx_runtime_1.jsx)("h3", { id: "activitiesHeader", children: "Activities" }), (0, jsx_runtime_1.jsx)("oj-list-view", { id: "activitiesList", class: "item-display", "aria-labelledby": "activitiesHeader", data: props.data, gridlines: gridlinesItemVisible, selectionMode: "single", scrollPolicy: "loadMoreOnScroll", scrollPolicyOptions: scrollPolicyOpts, selected: activityValue, onfirstSelectedItemChanged: selectedActivityChanged, children: (0, jsx_runtime_1.jsx)("template", { slot: "itemTemplate", render: listItemRenderer }) })] }));
    };
    exports.default = ActivityContainer;
});
//# sourceMappingURL=ActivityContainer.js.map