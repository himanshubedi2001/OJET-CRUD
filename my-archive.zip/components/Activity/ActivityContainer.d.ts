import { h } from "preact";
import "ojs/ojlistview";
import { RESTDataProvider } from "ojs/ojrestdataprovider";
type Props = {
    data?: RESTDataProvider<Activity["id"], Activity>;
    value?: string;
    onActiivityChanged: (value: Item) => void;
};
type Item = {
    id: number;
    name: string;
    short_desc?: string;
    price?: number;
    quantity?: number;
    quantity_shipped?: number;
    quantity_instock?: number;
    activity_id?: number;
    image?: string;
};
type Activity = {
    id: number;
    name: string;
    short_desc: string;
};
declare const ActivityContainer: (props: Props) => h.JSX.Element;
export default ActivityContainer;
