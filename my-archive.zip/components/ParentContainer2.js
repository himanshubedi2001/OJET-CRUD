var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
define(["require", "exports", "preact/jsx-runtime", "./ItemDetail/ItemDetailContainer", "./ActivityItem/ActivityItemContainer", "preact/hooks", "ojs/ojrestdataprovider"], function (require, exports, jsx_runtime_1, ItemDetailContainer_1, ActivityItemContainer_1, hooks_1, ojrestdataprovider_1) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    const baseServiceUrl = "https://apex.oracle.com/pls/apex/oraclejet/lp/activities/";
    let INIT_DATAPROVIDER = new ojrestdataprovider_1.RESTDataProvider({
        keyAttributes: "id",
        url: baseServiceUrl,
        transforms: {
            fetchFirst: {
                request: null,
                response: () => {
                    return { data: [] };
                },
            },
        },
    });
    const ParentContainer2 = (props) => {
        const [selectedItemVal, setSelectedItemVal] = (0, hooks_1.useState)(null);
        const [activityItemDP, setactivityItemDP] = (0, hooks_1.useState)(INIT_DATAPROVIDER);
        const activityItemChangeHandler = (0, hooks_1.useCallback)((item) => {
            setSelectedItemVal(item);
        }, []);
        (0, hooks_1.useEffect)(() => {
            var _a;
            setactivityItemDP(new ojrestdataprovider_1.RESTDataProvider({
                keyAttributes: "id",
                capabilities: {
                    filter: {
                        textFilter: true,
                    },
                },
                url: baseServiceUrl + "/" + ((_a = props.activity) === null || _a === void 0 ? void 0 : _a.id) + "/items/",
                textFilterAttributes: ["name"],
                transforms: {
                    fetchFirst: {
                        request: (options) => __awaiter(void 0, void 0, void 0, function* () {
                            const url = new URL(options.url);
                            const { size, offset } = options.fetchParameters;
                            url.searchParams.set("limit", String(size));
                            url.searchParams.set("offset", String(offset));
                            const filterCriterion = options.fetchParameters.filterCriterion;
                            const { textFilterAttributes } = options.fetchOptions;
                            if (filterCriterion &&
                                filterCriterion.text &&
                                textFilterAttributes) {
                                const { text } = filterCriterion;
                                textFilterAttributes.forEach((attribute) => {
                                    url.searchParams.set(attribute, text);
                                });
                            }
                            return new Request(url.href);
                        }),
                        response: ({ body }) => __awaiter(void 0, void 0, void 0, function* () {
                            const { items, totalSize, hasMore } = body;
                            return { data: items, totalSize, hasMore };
                        }),
                    },
                },
            }));
        }, [props.activity]);
        const showItems = (0, hooks_1.useCallback)(() => {
            return selectedItemVal === null ? false : true;
        }, [selectedItemVal]);
        return ((0, jsx_runtime_1.jsxs)("div", { id: "parentContainer2", class: "oj-flex oj-flex-item oj-lg-padding-6x-horizontal oj-md-8 oj-sm-12 oj-bg-success-20", children: [(0, jsx_runtime_1.jsx)(ActivityItemContainer_1.default, { selectedActivity: props.activity, data: activityItemDP, onItemChanged: activityItemChangeHandler }), showItems() && ((0, jsx_runtime_1.jsx)(ItemDetailContainer_1.default, { item: selectedItemVal })), !showItems() && ((0, jsx_runtime_1.jsx)("h4", { class: "oj-typography-subheading-sm", children: "Select activity item to see details" }))] }));
    };
    exports.default = ParentContainer2;
});
//# sourceMappingURL=ParentContainer2.js.map