define(["require", "exports", "preact/jsx-runtime", "../ParentContainer1"], function (require, exports, jsx_runtime_1, ParentContainer1_1) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    const Content = () => {
        return ((0, jsx_runtime_1.jsxs)("div", { class: "oj-web-applayout-max-width oj-web-applayout-content", children: [(0, jsx_runtime_1.jsx)("h1", { children: "Product Information" }), (0, jsx_runtime_1.jsx)(ParentContainer1_1.default, {})] }));
    };
    exports.default = Content;
});
//# sourceMappingURL=Content.js.map