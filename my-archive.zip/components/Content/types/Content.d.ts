import { h } from "preact";
declare const Content: () => h.JSX.Element;
export default Content;
