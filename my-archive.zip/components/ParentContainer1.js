var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
define(["require", "exports", "preact/jsx-runtime", "./Activity/ActivityContainer", "./ParentContainer2", "preact/hooks", "ojs/ojrestdataprovider"], function (require, exports, jsx_runtime_1, ActivityContainer_1, ParentContainer2_1, hooks_1, ojrestdataprovider_1) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    let keyAttributes = "id";
    const restServerURLActivities = "https://apex.oracle.com/pls/apex/oraclejet/lp/activities/";
    let INIT_SELECTEDACTIVITY = null;
    const ParentContainer1 = () => {
        const activityDataProvider = new ojrestdataprovider_1.RESTDataProvider({
            keyAttributes: keyAttributes,
            url: restServerURLActivities,
            transforms: {
                fetchFirst: {
                    request: (options) => __awaiter(void 0, void 0, void 0, function* () {
                        console.log("options \n ", options);
                        const url = new URL(options.url);
                        console.log("url 1", url);
                        const { size, offset } = options.fetchParameters;
                        url.searchParams.set("limit", String(size));
                        url.searchParams.set("offset", String(offset));
                        console.log("url 2", url);
                        return new Request(url.href);
                    }),
                    response: ({ body }) => __awaiter(void 0, void 0, void 0, function* () {
                        const { items, totalSize, hasMore } = body;
                        console.log("result \n ", items, totalSize, hasMore);
                        return { data: items, totalSize, hasMore };
                    }),
                },
            },
        });
        const [selectedActivity, setSelectedActivity] = (0, hooks_1.useState)(INIT_SELECTEDACTIVITY);
        const showActivityItems = () => {
            return selectedActivity != null ? true : false;
        };
        const activityChangedHandler = (value) => {
            setSelectedActivity(value);
        };
        return ((0, jsx_runtime_1.jsxs)("div", { id: "parentContainer1", class: "oj-flex oj-flex-init oj-panel oj-bg-warning-20", children: [(0, jsx_runtime_1.jsx)(ActivityContainer_1.default, { data: activityDataProvider, onActiivityChanged: activityChangedHandler }), showActivityItems() && ((0, jsx_runtime_1.jsx)(ParentContainer2_1.default, { activity: selectedActivity })), !showActivityItems() && ((0, jsx_runtime_1.jsx)("h4", { class: "oj-typography-subheading-sm", children: "Select activity to view items" }))] }));
    };
    exports.default = ParentContainer1;
});
//# sourceMappingURL=ParentContainer1.js.map