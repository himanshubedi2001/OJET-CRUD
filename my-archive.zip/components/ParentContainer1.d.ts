import { h } from "preact";
declare const ParentContainer1: () => h.JSX.Element;
export default ParentContainer1;
